# -*- coding: utf-8 -*-
"""
Created on Mon Nov 28 16:48:05 2016

@author: Gadsby
"""


from PyBioMed.test import test_PyBioMed  

test_PyBioMed.test_pybiomed()















